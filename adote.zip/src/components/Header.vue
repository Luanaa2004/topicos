<template>
  <nav class="navbar navbar-expand-lg bg-light">
    <div class="container">
      <a class="navbar-brand display-1 text primary" href="#">
        <img src="https://img.icons8.com/dusk/64/000000/pets.png" />
        Adote um amiguinho
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <ListItem texto="Quem somos" />
          <ListItem texto="Quero ajudar" />
          <ListItem texto="Quero Adotar" />
          <ListItem texto="Parceria" />
          <ListItem texto="Blog" />
        </ul>
        <form class="d-flex" role="search">
          <router-link to="/login" class="btn btn-outline-primary mr-2"
            >Entar</router-link
          >

          <button class="btn btn-outline-success" type="submit">
            Cadastrar
          </button>
        </form>
      </div>
    </div>
  </nav>
</template>

<script>
import ListItem from "./ListItem";
export default {
  name: "Header",
  componentes: {
    ListItem,
  },
};
</script>