<template>
  <div class="posts row row-cols-lg-4 row-cols-md-2 row-cols-sm-1">
    <Cartao v-for="post in posts" :info="post" :key="post.id" />
  </div>
</template>

<script>
import Cartao from "./Utils/Cartao";
import { posts } from "./fakeBD/posts";
export default {
  name: "BlogPosts",
  componentes: {
    Cartao,
  },
  setup() {
    return {
      posts,
    };
  },
};
</script>