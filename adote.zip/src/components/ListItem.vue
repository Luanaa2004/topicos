<template>
  <li class="nav item">
    <a class="nav-link text-primary" href="#">{{ texto }}</a>
  </li>
</template>

<script>
export default {
  name: "ListItem",
  props: {
    texto: String,
  },
};
</script>