<template>
  <div class="card m-2" style="width: 18rem">
    <img :src="info.img" class="card-img-top" :alt="info.titulo" />
    <div class="card-body">
      <h5 class="card-title">{{ info.titulo }}</h5>
      <p class="card-text">
        {{ info.texto }}
      </p>
      <a v-if="info.mostrarBtn" :href="info.linkBtn" class="btn btn-primary"
        >Ver mais -></a
      >
    </div>
  </div>
</template>

<script>
export default {
  name: "Cartao",
  props: {
    info: {
      img: String,
      titulo: String,
      texto: String,
      linkBtn: String,
      mostrarBtn: Boolean,
    },
  },
};
</script>