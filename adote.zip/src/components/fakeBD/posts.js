export const posts = [
  {
    id: 1,
    img:
      "https://site.amigonaosecompra.com.br/wp-content/uploads/2022/08/jeremy-stewardson-_4tMntYdypk-unsplash-750x450.jpg",
    titulo: "Responsabilidade afetiva pet, você sabe o que é?",
    texto:
      "Quando a gente gosta, é claro que a gente cuida, já dizia Caetano Veloso em sua música. Mas o que será que cabe no cuidar? É suficiente para um animal ter apenas água fresca e ração? É sobre isso que vamos falar hoje",
    mostrarBtn: true,
    linkBtn:
      "https://site.amigonaosecompra.com.br/responsabilidade-afetiva-pet-voce-sabe-o-que-e/"
  },
  {
    id: 2,
    img:
      "https://site.amigonaosecompra.com.br/wp-content/uploads/2022/01/istockphoto-1349366422-170667a.jpeg",
    titulo: "2022: há razões para acreditar",
    texto:
      "É muito comum no final do ano ou mesmo no início de um novo ano, fazer reflexões sobre a vida, listar sonhos, novas práticas que se deseja inserir neste novo ciclo.",
    mostrarBtn: true,
    linkBtn:
      "https://site.amigonaosecompra.com.br/2022-ha-razoes-para-acreditar/"
  },
  {
    id: 3,
    img:
      "https://site.amigonaosecompra.com.br/wp-content/uploads/2021/11/istockphoto-1270941390-170667a.jpeg",
    titulo: "Um animal de rua me mordeu. E agora?",
    texto:
      "Quem realiza resgates animais provavelmente já foi mordido por um animal de rua. Mas também pode acontecer de um cachorro que fugiu de casa e está assustado ou mesmo se você, assim como eu, não pode ver um bichinho na rua que já para fazer um carinho. Mas o que fazer quando um animal desconhecido te morde?",
    mostrarBtn: true,
    linkBtn:
      "https://site.amigonaosecompra.com.br/um-animal-de-rua-me-mordeu-e-agora/"
  },
  {
    id: 4,
    img:
      "https://site.amigonaosecompra.com.br/wp-content/uploads/2021/10/istockphoto-1131996037-170667a.jpeg",
    titulo: "Queda de pelos nos pets: saiba quando se preocupar",
    texto:
      "Eu não sei vocês, mas ver os pelos dos bichinhos voando pela casa é uma coisa que me preocupa. Claro, não apenas por uma questão de limpeza, mas também porque acho que em algum momento os gatos aqui de casa vão ficar carecas! Mas espera, dá pra perder tanto pelo assim?",
    mostrarBtn: true,
    linkBtn:
      "https://site.amigonaosecompra.com.br/queda-de-pelos-nos-pets-saiba-quando-se-preocupar/"
  }
];
