<template>
  <h2 class="text-warning mt-4">{{ maior }}</h2>
  <p class="text-muted">{{ menor }}</p>
</template>

<script>
export default {
  name: "SubTitulo",
  props: {
    maior: String,
    menor: String,
  },
};
</script>