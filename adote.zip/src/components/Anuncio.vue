<template>
  <div class="img-anuncio p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5 d-flex justify-content-between">
      <div class="txt-esq">
        <p class="fs-4">Mais de</p>
        <h1 class="display-5 fw-bold">10 mil</h1>
        <p class="fs-4">Animais adotados</p>
      </div>
      <div class="txt-dir">
        <p class="fs-4">Mais de</p>
        <h1 class="display-5 fw-bold">50 mil</h1>
        <p class="fs-4">Animais adotados</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Anuncio",
};
</script>
<style scoped>
.img-anuncio {
  background-image: url("https://as2.ftcdn.net/v2/jpg/00/31/84/35/1000_F_31843527_vuGbXlFVcTZ9FMvz1ymSFHo5r789YhdK.jpg");
  background-repeat: no-repeat;
  background-size: contain;
}
</style>