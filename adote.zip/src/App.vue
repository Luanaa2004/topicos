<template>
  <!--Header com menu -->
  <Header />

  <router-view></router-view>
  <!-- Foorter -->
  <Footer />
</template>

<script>
import Header from "./components/Header";

import Footer from "./components/Footer";
export default {
  name: "App",
  components: {
    Footer,
    Header,
  },
};
</script>
