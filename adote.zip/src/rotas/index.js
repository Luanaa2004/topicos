import { createRouter, createWebHashHistory } from "vue-router";

import Principal from "../telas/Principal";
import Login from "../telas/Login";
import Admin from "../telas/Admin";

const telas = [
  {
    path: "/",
    name: "Principal",
    component: Principal
  },
  {
    path: "/login",
    name: "Login",
    component: Login
  },
  {
    path: "/admin",
    name: "Admin",
    component: Admin
  }
];
