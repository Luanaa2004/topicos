<template>
  <div class="principal container">
    <!--Anuncio-->

    <Anuncio />

    <!-- Botoes -->
    <div class="botoes d-flex">
      <button class="btn btn-info flex-fill m-1">Quero Adotar</button>
      <button class="btn btn-outline-info flex-fill m-1">Quero Divulgar</button>
    </div>
    <!--Cards dos Animais -->
    <SubTitulo
      maior="Nossos Amiguinhos"
      menor="Nosso site esta cheio de amiguinhos de quatro patas esperando um lar"
    />
    <!--<p v-for="animal in animais" :key="animal.id">{{ animal.nome }}</p>-->
    <!-- Cards do blog -->
    <div class="row">
      <div
        v-for="animal in animais"
        :key="animal.id"
        class="col-lg-3 col-md-6 col-sm-12"
      >
        <Cartao info="animal" />
      </div>
    </div>
    <SubTitulo maior="Para que adotar?" />

    <SubTitulo
      maior="Blog do Amigo"
      menor="Veja nossas ultimas dicas sobre cuidados"
    />

    <BlogPosts />
  </div>
</template>


<script>
import Anuncio from "../components/Anuncio";
import SubTitulo from "../components/SubTitulo";
import BlogPosts from "../components/BlogPosts";
import api from "../api";
import Cartao from "../components/Utils/Cartao";
export default {
  name: "Principal",
  components: {
    Anuncio,
    SubTitulo,
    BlogPosts,
    Cartao,
  },
  methods: {
    preencherLista(lista) {
      this.animais = lista;
    },
  },
  data() {
    return {
      animais: [],
    };
  },
  mounted() {
    api.get("/animal").then((resp) => {
      this.preencherLista(resp.data);
    });
  },
};
</script>