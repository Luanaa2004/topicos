<template>
  <h1>Tela Admin</h1>
</template>


<script>
export default {
  name: "Admin",
};
</script>